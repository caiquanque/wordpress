<?php

require_once( get_template_directory() . '/inc/const.php' );

require_once( get_template_directory() . '/inc/homepage_functions.php' );

require_once( get_template_directory() . '/inc/foods_functions.php' );

require_once( get_template_directory() . '/inc/ourstory_functions.php' );

require_once( get_template_directory() . '/inc/custom_posts_functions.php' );

require_once( get_template_directory() . '/inc/manager_functions.php' );


/*
	==========================================
	 Include scripts
	==========================================
*/
function thong_script_enqueue() {

	//css
	wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css', array(), NULL, 'all' );
	wp_register_style( 'font_awesome', 'https://use.fontawesome.com/releases/v5.1.0/css/all.css' );
	wp_enqueue_style( 'font_awesome' );

	//js

	wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/assets/js/modernizr.js', array(), NULL, false );
	wp_enqueue_script( 'script', get_template_directory_uri() . '/assets/js/script.js', array(), NULL, true );
}

add_action( 'wp_enqueue_scripts', 'thong_script_enqueue' );


/*
	==========================================
	 Activate theme support
	==========================================
*/
function thong_add_theme_support() {

	add_theme_support( 'post-thumbnails', array( 'post', 'page', 'event','investor_updates' ) );
	add_post_type_support( 'page', 'excerpt' );
	add_post_type_support( 'post', 'page-attributes' );
    add_post_type_support( 'investor_updates', 'page-attributes' );

}

add_action( 'init', 'thong_add_theme_support' );


/*
	==========================================
	 Activate menus
	==========================================
*/
function thong_setup_menus() {

	add_theme_support( 'menus' );

	register_nav_menu( 'header', 'Header Navigation' );
	register_nav_menu( 'footer_1', 'Footer First Column Navigation' );
	register_nav_menu( 'footer_2', 'Footer Second Column Navigation' );
	register_nav_menu( 'footer_3', 'Footer Third Column Navigation' );
	register_nav_menu( 'footer_4', 'Footer Fourth Column Navigation' );
	register_nav_menu( 'footer_5', 'Footer Fifth Column Navigation' );

}

add_action( 'init', 'thong_setup_menus' );


/*
	==========================================
	 Activate custom logo
	==========================================
*/
function thong_setup_logo() {

	add_theme_support( 'custom-logo' );

}

add_action( 'init', 'thong_setup_logo' );


/*
	==========================================
	 Change custom logo url class
	==========================================
*/
function change_logo_class( $class ) {

    return str_replace( 'custom-logo-link', 'logo', $class );

}

add_filter( 'get_custom_logo', 'change_logo_class' );


/*
	==========================================
	 Main menu walker
	==========================================
*/

class walker_main_menu extends Walker_Nav_menu {

	public function start_lvl( &$output, $depth = 0, $args = array() ) {

		$indent = str_repeat( "\t", $depth );
		$output .= "\n$indent<ul class=\"navigation-2\" data-sub-item-group>\n";

	}

	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = $depth === 0 ? 'navigation-1__item' : 'navigation-2__item';
		$classes[] = ($args->walker->has_children) ? 'has-child' : '';
		$classes[] = ( $item->current || $item->current_item_ancestor ) ? 'open' : '';

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '" data-item';

		$output .= $indent . '<li' . $class_names . '>';

		$attributes = ! empty( $item->attr_title ) ? ' title="' . esc_attr( $item->attr_title ) . '"' : '';
		$attributes .= ! empty( $item->target ) ? ' target="' . esc_attr( $item->target ) . '"' : '';
		$attributes .= ! empty( $item->xfn ) ? ' rel="' . esc_attr( $item->xfn ) . '"' : '';
		$attributes .= ! empty( $item->url ) ? ' href="' . esc_attr( $item->url ) . '"' : '';

		$item_output = $args->before . '<a' . $attributes . '>';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID );
		$item_output .= $args->link_after . '</a>';
        $item_output .= ( $depth == 0 && $args->walker->has_children ) ? '<span class="icon icon-arrow-down" data-open-group></span>':'';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );

	}
}

/*
	==========================================
	 Footer menu walker
	==========================================
*/

class walker_footer_menu extends Walker_Nav_menu {
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = $depth === 0 ? 'footer-menu__item-parent' : 'footer-menu__item-child';

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '" data-item';

		$output .= $indent . '<li' . $class_names . '>';

		$attributes = ! empty( $item->attr_title ) ? ' title="' . esc_attr( $item->attr_title ) . '"' : '';
		$attributes .= ! empty( $item->target ) ? ' target="' . esc_attr( $item->target ) . '"' : '';
		$attributes .= ! empty( $item->xfn ) ? ' rel="' . esc_attr( $item->xfn ) . '"' : '';
		$attributes .= ! empty( $item->url ) ? ' href="' . esc_attr( $item->url ) . '"' : '';

		$item_output = $args->before . '<a' . $attributes . '>';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID );
		$item_output .= $args->link_after . '</a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );

	}
}

/*
	==========================================
	 Slider custom post extra field
	==========================================
*/
function thong_slider() {
	$prefix = 'thong_slider_';

	$thong_slider = new_cmb2_box( [
		'id'           => $prefix . 'block',
		'title'        => __( 'Vinh Hoan slider', THONG ),
		'object_types' => [ 'slider' ]
	] );

	$thong_slider->add_field( [
		'name' => __( 'Time for slide', THONG ),
		'id'   => $prefix . 'time_for_slide',
		'type' => 'text'
	] );

	$thong_slider->add_field( [
		'name'             => __( 'Location', THONG ),
		'id'               => $prefix . 'location',
		'type'             => 'select',
		'show_option_none' => false,
		'options'          => [
			'home_banner'         => __( 'Homepage banner', THONG ),
			'footer'              => __( 'Footer slider', THONG ),
			'vinh_food'           => __( 'Vinh food homepage', THONG ),
			'foods_foods'  => __( 'Foods Introduction banner', THONG ),
			'foods_ready-to-cook' => __( 'Foods Ready to cook banner', THONG ),
			'foods_ready-to-eat'  => __( 'Foods Ready to eat banner', THONG ),
			'ourstory_who-we-are-banner' => __( 'Our Story Who We Are Banner', THONG ),
			'ourstory_who-we-are-slider' => __( 'Our Story Who We Are Slider', THONG ),
		],
	] );

	$group_field_id = $thong_slider->add_field( [
		'id'      => $prefix . 'slide',
		'type'    => 'group',
		'options' => [
			'group_title'   => __( 'Slide {#}', THONG ),
			'add_button'    => __( 'Add Another slide', THONG ),
			'remove_button' => __( 'Remove slide', THONG )
		]
	] );

	$thong_slider->add_group_field( $group_field_id, [
		'name' => __( 'Slide Image', THONG ),
		'id'   => $prefix . 'image',
		'type' => 'file',
	] );

    $thong_slider->add_group_field( $group_field_id, [
        'name' => __( 'Slide Image for tablet', THONG ),
        'id'   => $prefix . 'image_tablet',
        'type' => 'file',
    ] );

    $thong_slider->add_group_field( $group_field_id, [
        'name' => __( 'Slide Image for mobile', THONG ),
        'id'   => $prefix . 'image_mobile',
        'type' => 'file',
    ] );

	$thong_slider->add_group_field( $group_field_id, [
		'name' => __( 'Slide URL', THONG ),
		'id'   => $prefix . 'url',
		'type' => 'text_url',
	] );

	$thong_slider->add_group_field( $group_field_id, [
		'name' => __( 'Slide Title', THONG ),
		'id'   => $prefix . 'title',
		'type' => 'text',
	] );

	$thong_slider->add_group_field( $group_field_id, [
		'name' => __( 'Slide Content', THONG ),
		'id'   => $prefix . 'content',
		'type' => 'wysiwyg',
		'options'=>[
			'textarea_rows'=> get_option('default_post_edit_rows', 5),
			'media_buttons'=>false,
			'teeny' => true,
		]
	] );

}

add_action( PLUGIN_CMB2_ADMIN_INIT, 'thong_slider' );


/*
	==========================================
     Category extra field
	==========================================
*/
function thong_category_extra_field() {

	$cmb_term = new_cmb2_box( [
		'id'           => 'cat_ex_box',
		'title'        => __( 'Category Metabox', THONG ), // Doesn't output for term boxes
		'object_types' => [ 'term' ], // Tells CMB2 to use term_meta vs post_meta
		'taxonomies'   => [ 'category' ], // Tells CMB2 which taxonomies should have these fields
	] );

	$cmb_term->add_field( [
		'name'         => __( 'Only show image', THONG ),
		'id'           => 'only_show_image',
		'type'         => 'checkbox'
	] );

	$cmb_term->add_field( [
		'name'    => __( 'Content', THONG ),
		'id'      => 'cat_content',
		'type'    => 'wysiwyg',
		'options' => [
			'media_buttons' => false,
			'teeny'         => true,
			'textarea_rows' => 5
		]
	] );

	$cmb_term->add_field( [
		'name'         => __( 'Order', THONG ),
		'id'           => 'cat_order',
		'type'         => 'text',
		'default'   => null,
		'attributes' => [
			'placeholder' => 'Enter custom order here',
			'type'    => 'number',
			'pattern' => '\d*',
			'min'      => 1,
		]
	] );

	$cmb_term->add_field( [
		'name'         => __( 'Image', THONG ),
		'id'           => 'cat_image',
		'type'         => 'file',
		'text'         => [
			'add_upload_file_text' => 'Add Image' // Change upload button text. Default: "Add or Upload File"
		],
		'preview_size' => 'large', // Image size to use when previewing in the admin.
	] );

}

add_action( PLUGIN_CMB2_ADMIN_INIT, 'thong_category_extra_field' );


/*
	==========================================
     Category custom order function
	==========================================
*/
function custom_order_cat($a, $b) {
	$a = (int)get_term_meta($a->term_id,'cat_order',1);
	$b = (int)get_term_meta($b->term_id,'cat_order',1);
	if($a === 0 && $b !== 0) {
	    return 1;
    }elseif($b === 0 && $a !== 0){
	    return -1;
    }
	return 0;
}

function clean_br_in_string($string){
    return preg_replace('#(<br */?>\s*)+#i', '<br />',nl2br($string));
}

add_theme_support('html5',array('search-form'));
