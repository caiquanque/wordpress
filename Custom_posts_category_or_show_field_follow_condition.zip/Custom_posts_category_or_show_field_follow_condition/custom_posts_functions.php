<?php
/*
	==========================================
	 Add sliders custom post type
	==========================================
*/
function thong_sliders_custom_post()
{

    $labels = [
        'name' => __('Sliders', THONG_THEME),
        'singular_name' => __('Slider', THONG_THEME),
        'add_new' => __('Add Slider', THONG_THEME),
        'all_items' => __('All Sliders', THONG_THEME),
        'add_new_item' => __('Add Slider', THONG_THEME),
        'edit_item' => __('Edit Slider', THONG_THEME),
        'new_item' => __('New Slider', THONG_THEME),
        'view_item' => __('View Slider', THONG_THEME),
        'search_item' => __('Search Slider', THONG_THEME),
        'not_found' => __('No sliders found', THONG_THEME),
        'not_found_in_trash' => __('No sliders found in trash', THONG_THEME),
        'parent_item_colon' => __('Parent Slider', THONG_THEME)
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => [
            'title',
            'thumbnail',
            'revisions',
        ],
        'menu_position' => 5,
        'menu_icon' => 'dashicons-images-alt',
        'exclude_from_search' => false
    ];
    register_post_type('slider', $args);
}

add_action('init', 'thong_sliders_custom_post');


/*
	==========================================
	 Add events custom post type
	==========================================
*/
function thong_events_custom_post()
{

    $labels = [
        'name' => __('Events', THONG_THEME),
        'singular_name' => __('Event', THONG_THEME),
        'add_new' => __('Add Event', THONG_THEME),
        'all_items' => __('All Events', THONG_THEME),
        'add_new_item' => __('Add Event', THONG_THEME),
        'edit_item' => __('Edit Event', THONG_THEME),
        'new_item' => __('New Event', THONG_THEME),
        'view_item' => __('View Event', THONG_THEME),
        'search_item' => __('Search Event', THONG_THEME),
        'not_found' => __('No events found', THONG_THEME),
        'not_found_in_trash' => __('No events found in trash', THONG_THEME),
        'parent_item_colon' => __('Parent Event', THONG_THEME)
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => [
            'title',
            'excerpt',
            'thumbnail',
            'revisions',
        ],
        'menu_position' => 6,
        'menu_icon' => 'dashicons-calendar-alt',
        'exclude_from_search' => false
    ];
    register_post_type('event', $args);
}

add_action('init', 'thong_events_custom_post');


/*
	==========================================
	 Add events custom post extra field
	==========================================
*/
function thong_event_ex_field()
{

    $event_ex_field = new_cmb2_box([
        'id' => 'event_extra_field',
        'title' => __('Event Extra Information', THONG_THEME),
        'object_types' => ['event'], // Post type
    ]);

    $event_ex_field->add_field([
        'name' => __('Sub title', THONG_THEME),
        'id' => 'event_sub_title',
        'type' => 'text',
    ]);

    $event_ex_field->add_field([
        'name' => __('Introduction', THONG_THEME),
        'id' => 'event_intro',
        'type' => 'text',
    ]);

    $event_ex_field->add_field([
        'name' => __('Booth number', THONG_THEME),
        'id' => 'event_boo_num',
        'type' => 'text',
        'default' => '',
    ]);

    $event_ex_field->add_field([
        'name' => __('Start time', THONG_THEME),
        'id' => 'event_start',
        'type' => 'text_date_timestamp',
        'date_format' => 'd-m-Y',
        'column' => true,
    ]);

    $event_ex_field->add_field([
        'name' => __('Duration', THONG_THEME),
        'id' => 'event_duration',
        'type' => 'text_small',
        'default' => 1,
        'attributes' => [
            'type' => 'number',
            'pattern' => '\d*',
            'min' => 1
        ]
    ]);

    $event_ex_field->add_field([
        'name' => __('Location', THONG_THEME),
        'id' => 'event_location',
        'type' => 'text'
    ]);

    $event_ex_field->add_field([
        'name' => __('Address', THONG_THEME),
        'id' => 'event_address',
        'type' => 'text'
    ]);

}

add_action(PLUGIN_CMB2_ADMIN_INIT, 'thong_event_ex_field');

/*
	==========================================
     Event reorder by date start event
	==========================================
*/
function reorder_event_by_start_date($a, $b)
{
    $a = date_create(get_post_meta($a->ID, 'event_start', 1));
    $b = date_create(get_post_meta($b->ID, 'event_start', 1));
    if ($a->getTimestamp() == $b->getTimestamp()) {
        return 0;
    }
    return ($a->getTimestamp() < $b->getTimestamp()) ? -1 : 1;
}


/*
	==========================================
	 Add investors custom post type
	==========================================
*/
function thong_investors_custom_post()
{

    $labels = [
        'name' => __('Investors', THONG_THEME),
        'singular_name' => __('Investor', THONG_THEME),
        'add_new' => __('Add Item', THONG_THEME),
        'all_items' => __('All Items', THONG_THEME),
        'add_new_item' => __('Add Item', THONG_THEME),
        'edit_item' => __('Edit Item', THONG_THEME),
        'new_item' => __('New Item', THONG_THEME),
        'view_item' => __('View Item', THONG_THEME),
        'search_item' => __('Search Item', THONG_THEME),
        'not_found' => __('No items found', THONG_THEME),
        'not_found_in_trash' => __('No items found in trash', THONG_THEME),
        'parent_item_colon' => __('Parent Item', THONG_THEME)
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => [
            'title',
            'editor',
            'excerpt',
            'thumbnail',
            'revisions',
            'page-attributes',
            'custom-fields'
        ],
        'menu_position' => 7,
        'menu_icon' => 'dashicons-welcome-write-blog',
        'exclude_from_search' => false
    ];
    register_post_type('investor_updates', $args);
}

add_action('init', 'thong_investors_custom_post');

function thong_investors_custom_taxonomies()
{

    $labels = array(
        'name' => 'Fields',
        'singular_name' => 'Field',
        'search_items' => 'Search Fields',
        'all_items' => 'All Fields',
        'parent_item' => 'Parent Field',
        'parent_item_colon' => 'Parent Field:',
        'edit_item' => 'Edit Field',
        'update_item' => 'Update Field',
        'add_new_item' => 'Add New Work Field',
        'new_item_name' => 'New Field Name',
        'menu_name' => 'Fields'
    );

    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'field')
    );

    register_taxonomy('field', array('investor_updates'), $args);

}

add_action('init', 'thong_investors_custom_taxonomies');

/*
	==========================================
	 Add investor extra field
	==========================================
*/
function thong_investor_annual_report_extra_field()
{

    $investor_extra_field = new_cmb2_box(
        [
            'id'           => 'thong_investor_extra_field',
            'title'        => __('Link File', THONG_THEME),
            'object_types' => ['investor_updates'], // Post type
            'show_on_cb'   => 'show_field_is_annual_report_page'
        ]
    );

    $investor_extra_field->add_field(
        [
            'name' => __('English Link File', THONG_THEME),
            'id'   => 'english_id_annual_report_download',
            'type' => 'file',
        ]
    );

    $investor_extra_field->add_field(
        [
            'name' => __('Vietnamese Link File', THONG_THEME),
            'id'   => 'vietnamese_id_annual_report_download',
            'type' => 'file',
        ]
    );

}

add_action(PLUGIN_CMB2_ADMIN_INIT, 'thong_investor_annual_report_extra_field');

/*
	==========================================
	 Add investor shareholders meetings extra field
	==========================================
*/
function thong_investor_shareholders_meetings_extra_field()
{

    $investor_shareholders_meetings_extra_field = new_cmb2_box(
        [
            'id'           => 'thong_investor_shareholders_meetings_extra_field',
            'title'        => __('List File', THONG_THEME),
            'object_types' => ['investor_updates'], // Post type
            'show_on_cb'   => 'show_field_is_shareholders_meetings_page'
        ]
    );

    $shareholders_meetings_group = $investor_shareholders_meetings_extra_field->add_field(
        [
            'id'      => 'shareholders_meetings_group',
            'type'    => 'group',
            'title'   => __('Shareholders Meetings News Options', THONG_THEME),
            'options' => [
                'group_title'   => __('File {#}', THONG_THEME),
                'add_button'    => __('Add Another File', THONG_THEME),
                'remove_button' => __('Remove File', THONG_THEME),
                'sortable'      => true,
                'closed'        => true,
            ],
        ]
    );

    $investor_shareholders_meetings_extra_field->add_group_field(
        $shareholders_meetings_group,
        [
            'name' => __('Title', THONG_THEME),
            'id'   => 'title_id_shareholders_meetings_extra_field',
            'type' => 'text',
        ]
    );

    $investor_shareholders_meetings_extra_field->add_group_field(
        $shareholders_meetings_group,
        [
            'name' => __('URL', THONG_THEME),
            'id'   => 'url_id_shareholders_meetings_extra_field',
            'type' => 'file',
        ]
    );

}

add_action(PLUGIN_CMB2_ADMIN_INIT, 'thong_investor_shareholders_meetings_extra_field');

/*
	==========================================
	 Add investor calendar extra field
	==========================================
*/
function get_field_is_page($investor_calendar) {

    if ( get_page_template() === get_home_path().$investor_calendar) {

        return true;
    }

    return false;
}

/*
	==========================================
	 Show field is calendar page
	==========================================
*/
function show_field_is_calendar_page() {

    $result = get_field_is_page(INVESTOR_CALENDAR);

    return $result;
}

/*
	==========================================
	 Show field is annual report page
	==========================================
*/
function show_field_is_annual_report_page() {

    $result = get_field_is_page(INVESTOR_ANNUAL_REPORT);

    return $result;
}

/*
	==========================================
	 Show field is annual report page
	==========================================
*/
function show_field_is_shareholders_meetings_page() {

    $result = get_field_is_page(INVESTOR_SHAREHOLDERS_MEETINGS);

    return $result;
}

/*
	==========================================
	 Vinh Hoan investor calendar extra field
	==========================================
*/
function thong_investor_calendar_extra_field()
{

    $info_calendar_extra_fields = new_cmb2_box(
        [
            'id'           => 'info_calendar_extra_fields_id',
            'title'        => __('Investor Calendar', THONG_THEME),
            'object_types' => ['page'],
            'show_on_cb'   => 'show_field_is_calendar_page'
        ]
    );

    $calendar_group = $info_calendar_extra_fields->add_field(
        [
            'id'      => 'calendar_group_id',
            'type'    => 'group',
            'title'   => __('Calendar News Options', THONG_THEME),
            'options' => [
                'group_title'   => __('Entry {#}', THONG_THEME),
                'add_button'    => __('Add Another Entry', THONG_THEME),
                'remove_button' => __('Remove Entry', THONG_THEME),
                'sortable'      => true,
                'closed'        => true,
            ],
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name'        => __('Date', THONG_THEME),
            'id'          => 'date_id',
            'type'        => 'text_date',
            'date_format' => 'd-M-Y',
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name'    => __('Time-GMT +7', THONG_THEME),
            'id'      => 'time_gmt_id',
            'type'    => 'select',
            'options' => array(
                'Not scheduled' => __('None', THONG_THEME),
                '1am'           => __('1am', THONG_THEME),
                '2am'           => __('2am', THONG_THEME),
                '3am'           => __('3am', THONG_THEME),
                '4am'           => __('4am', THONG_THEME),
                '5am'           => __('5am', THONG_THEME),
                '6am'           => __('6am', THONG_THEME),
                '7am'           => __('7am', THONG_THEME),
                '8am'           => __('8am', THONG_THEME),
                '9am'           => __('9am', THONG_THEME),
                '10am'          => __('10am', THONG_THEME),
                '11am'          => __('11am', THONG_THEME),
                '12am'          => __('12am', THONG_THEME),
                '1pm'           => __('1pm', THONG_THEME),
                '2pm'           => __('2pm', THONG_THEME),
                '3pm'           => __('3pm', THONG_THEME),
                '4pm'           => __('4pm', THONG_THEME),
                '5pm'           => __('5pm', THONG_THEME),
                '6pm'           => __('6pm', THONG_THEME),
                '7pm'           => __('7pm', THONG_THEME),
                '8pm'           => __('8pm', THONG_THEME),
                '9pm'           => __('9pm', THONG_THEME),
                '10pm'          => __('10pm', THONG_THEME),
                '11pm'          => __('11pm', THONG_THEME),
                '12pm'          => __('12pm', THONG_THEME),
            ),
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name' => __('Content/Event', THONG_THEME),
            'id'   => 'content_event_id',
            'type' => 'text',
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name' => __('Materials Title', THONG_THEME),
            'id'   => 'materials_title_id',
            'type' => 'text',
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name' => __('Materials Link', THONG_THEME),
            'id'   => 'materials_link_id',
            'type' => 'text_url',
        ]
    );

    $info_calendar_extra_fields->add_group_field(
        $calendar_group,
        [
            'name' => __('Add To Calendar Link', THONG_THEME),
            'id'   => 'add_to_calendar_link_id',
            'type' => 'text_url',
        ]
    );

}

add_action(PLUGIN_CMB2_ADMIN_INIT, 'thong_investor_calendar_extra_field');


/*
	==========================================
	 Investor custom categories
	==========================================
*/
function thong_investors_custom_categories()
{

    $labels = [
        'name'              => __('Categories', THONG_THEME),
        'singular_name'     => __('Category', THONG_THEME),
        'search_items'      => __('Search Categories', THONG_THEME),
        'all_items'         => __('All Categories', THONG_THEME),
        'parent_item'       => __('Parent Category', THONG_THEME),
        'parent_item_colon' => __('Parent Category:', THONG_THEME),
        'edit_item'         => __('Edit Category', THONG_THEME),
        'update_item'       => __('Update Category', THONG_THEME),
        'add_new_item'      => __('Add New Category', THONG_THEME),
        'new_item_name'     => __('New Category Name', THONG_THEME),
        'menu_name'         => __('Categories', THONG_THEME),
    ];

    register_taxonomy(
        'investor_category',
        ['investor_updates'],
        [
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => ['slug' => 'investor_category'],
        ]
    );

}

add_action('init', 'thong_investors_custom_categories');

/*
	==========================================
	 Get list shareholders meetings to json
	==========================================
*/
    function get_list_shareholders_meetings_to_json() {

        $shareholders_meetings_id = get_term_by('slug','shareholders-meetings','investor_category')->term_id;
        $shareholders_posts       = get_posts( [
            'post_type'      => 'investor_updates',
            'tax_query'      => [
                [
                    'taxonomy' => 'investor_category',
                    'field'    => 'term_id',
                    'terms'    => $shareholders_meetings_id,
                ]
            ],
            'orderby'        => [ 'menu_order' => 'ASC', 'ID' => 'ASC' ],
            'posts_per_page' => - 1
        ] );

        header( 'Content-Type: application/json' );

        if ( count( $shareholders_posts ) ):

            _e( '{
  "data": [', THONG_THEME );
            foreach ( $shareholders_posts as $post_index => $shareholders_post ) :
                echo "<pre>";
                print_r($shareholders_post);
                _e( '
    {
      "title": "' . str_replace( '"', "'", $shareholders_post->post_title ) . '",
      "files": 
          [', THONG_THEME );
                $shareholders_files = get_post_cmb2( 'shareholders_meetings_items', $shareholders_post->ID );
                foreach ( $shareholders_files as $file_index => $shareholders_file ):
                    _e( '
            "' . str_replace( '"', "'", $shareholders_file["shareholders_meetings_title"] ) . '"', THONG_THEME );
                    _e( $file_index < count( $shareholders_files ) - 1 ? ',' : '', THONG_THEME );
                endforeach;
                _e( '
          ],
      "button": "Download"
    }', THONG_THEME );
                _e( $post_index < count( $shareholders_posts ) - 1 ? ',' : '', THONG_THEME );
            endforeach;
            _e( '
  ]
}', THONG_THEME );
        endif;
        exit;
}
add_action('wp_ajax_get_list_shareholders_meetings_to_json', 'get_list_shareholders_meetings_to_json');