<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 24/07/2018
 * Time: 14:10
 */

define ( 'THONG_THEME', 'thong_theme' );
define ( 'PLUGIN_CMB2_ADMIN_INIT', 'cmb2_admin_init' );
define ( 'NUMBER_MONTH_TO_SHOW_EVENT', 18 );
define ( 'INVESTOR_CALENDAR', 'wp-content/themes/thong-microsites/templates/template-investor_calendar.php' );
define ( 'INVESTOR_ANNUAL_REPORT', 'wp-content/themes/thong-microsites/templates/template-investors_annual_reports.php' );
define ( 'INVESTOR_SHAREHOLDERS_MEETINGS', 'wp-content/themes/thong-microsites/templates/template-investors_shareholders_meetings.php' );