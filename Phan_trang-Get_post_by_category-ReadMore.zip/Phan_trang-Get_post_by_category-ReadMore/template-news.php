<?php
/**
 * Template Name: News
 */

get_header();
?>
    <main class="main">
        <?php
        $news_cat_id = get_term_by('slug', 'news', 'category')->term_id;
        $paged       = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $news_query  = new WP_Query(
            [
                'post_type'      => 'post',
                'cat'            => $news_cat_id,
                'posts_per_page' => 3,
                'paged'          => $paged,
                'orderby'        => [
                    'menu_order' => 'DESC',
                    'date'       => 'DESC',
                ],
            ]
        );
        ?>
        <section class="recent-new paddingtop-150 paddingbot-50 full-height-section">
            <div class="container">
                <div class="title-3"><?php _e($post->post_title, THONG); ?></div>
                <div class="row m-t-30">
                    <?php
                    if ($news_query->have_posts()) :
                        while ($news_query->have_posts()) : $news_query->the_post();
                            ?>
                            <div class="col-md-4 col-sm-6">
                                <div class="recent-new__main has-bgd" data-matching-height>
                                    <?php if (get_the_post_thumbnail_url(get_the_ID())): ?>
                                        <div class="recent-new__image">
                                            <a
                                                    href="<?php _e(get_permalink(), THONG); ?>">
                                                <img alt="alt images"
                                                     src="<?php _e(
                                                         get_the_post_thumbnail_url(get_the_ID(), 'full'),
                                                         THONG
                                                     ); ?>">
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="recent-new__main-content">
                                        <div class="date">
                                            <a href="<?php _e(get_permalink(), THONG); ?>">
                                                <?php _e(
                                                    get_the_date('d/m/Y'),
                                                    THONG
                                                ); ?>
                                            </a>
                                        </div>
                                        <div class="title">
                                            <a href="<?php _e(get_permalink(), THONG); ?>">
                                                <?php _e(get_the_title()); ?>
                                            </a>
                                        </div>
                                        <?php if ( !get_the_post_thumbnail_url(get_the_ID())): ?>
                                            <div class="desc">
                                                <a href="<?php _e(get_permalink(), THONG); ?>">
                                                    <?php
                                                    _e(wp_trim_words(get_the_excerpt(), 25, '...'), THONG);
                                                    ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        <?php
                        endwhile;
                    endif;
                    ?>
                </div>
                <div class="row">
                    <div class="pagination">
                        <?php
                        $max_num_page = $news_query->max_num_pages;
                        $pagination   = paginate_links(
                            [
                                'format'    => '?paged=%#%',
                                'show_all'  => false,
                                'prev_text' => __(''),
                                'next_text' => __(''),
                                'total'     => $max_num_page,
                                'type'      => 'list',
                            ]
                        );
                        _e($pagination, THONG); ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php get_footer(); ?>