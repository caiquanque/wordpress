========================================
================Phan Trang==============
========================================

; Get post by category-news
; $paged >>>> Get nội dung từng page.
; $news_cat_id >>>>>>>>> get term_id
; wp_trim_words(get_the_excerpt(), 25, '...') >>>> Read more, Get excerpt độ dài đoạn 25 từ sau đó là dấu ...

$news_cat_id = get_term_by('slug', 'news', 'category')->term_id;
$paged       = (get_query_var('paged')) ? get_query_var('paged') : 1;
$news_query  = new WP_Query(
    [
        'post_type'      => 'post',
        'cat'            => $news_cat_id,
        'posts_per_page' => 3,
        'paged'          => $paged,
        'orderby'        => [
            'menu_order' => 'DESC',
            'date'       => 'DESC',
        ],
    ]
);
$max_num_page = $news_query->max_num_pages;
$pagination   = paginate_links(
    [
        'format'    => '?paged=%#%',
        'show_all'  => false,
        'prev_text' => __(''),
        'next_text' => __(''),
        'total'     => $max_num_page,
        'type'      => 'list',
    ]
);
_e($pagination, THONG); ?>
